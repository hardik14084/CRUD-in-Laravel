<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insert Data</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Bodoni+Moda:wght@400;900&display=swap');

        *{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Bodoni Moda', serif;
}

.input-field{
    background: #eaeaea;
    margin: 15px 0;
    border-radius: 5px;
    display: flex;
    align-items: center;
    max-height: 65px;
    transition: max-height 1s;
    overflow: hidden;
    text-shadow: 2px 2px 5px black; 
    font-size: 1.2rem;
}

input{
    width: 100%;
    background: transparent;
    border: 0;
    outline: 0;
    padding: 18px 15px;
    color: black;
}

.input-field i {
    margin-left: 15px;
    /* color: #999; */
    color: orange;
}

.btn-field{
    width: 40%;
    display: flex;
    align-items: center;
}

.btn-field {
    margin-top: 30px;
    flex-basis: 48%;
    background: rgb(255, 158, 2);
    color: #fff;
    height: 50px;
    border-radius: 20px;
    border: 0;
    outline: 0;
    cursor: pointer;
    transition: backgroud 1s;
    width: 100%;
}

.disable{
    font-size: 2rem;
    padding: 10px;
    cursor: pointer;
    color: #fff;
}

.disable:hover{
    color: rgb(255, 17, 4);
}

        </style>
    <link rel="shortcut icon" href="../img/login.png" type="image/x-icon">
    <script src="https://kit.fontawesome.com/0eae2c197f.js" crossorigin="anonymous"></script>
</head>
<body>
   
    <div class="container">
        <div class="form-box">
            <h1 id="title">Student Record</h1>
            <form action="#" method="post" action="{{route('insert.save')}}">
            @csrf
                <div class="input-group">

                    <div class="input-field">
                        <i class="fa-solid fa-id-card"></i>
                        <input type="text" required placeholder="Student Id" name="stdid">
                    </div>

                    <div class="input-field" id="namefield">
                        <i class="fa-solid fa-user"></i>
                        <input type="text" required placeholder="first Name" name="usname">
                    </div>
                    <div class="input-field">
                        <i class="fa-sharp fa-solid fa-address-book" style="color: #fb9b13;"></i>
                        <input type="textarea" required placeholder="Address" name="add">
                    </div>
                    


                    <div class="input-field">
                        <i class="fa-solid fa-envelope"></i>
                        <input type="email" required placeholder="E-mail" name="email">
                    </div>

                </div>

                <div class="btn-field">
                    <input type="submit" name="Insert Record" class="disable" id="signinbtn" value="Insert Record">
                </div>

            </form>
        </div>
    </div>
     
    <script src="https://kit.fontawesome.com/0eae2c197f.js" crossorigin="anonymous"></script>
 
</body>
</html>