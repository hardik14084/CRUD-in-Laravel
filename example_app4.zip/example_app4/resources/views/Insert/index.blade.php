<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insert Data</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Bodoni+Moda:wght@400;900&display=swap');

        *{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Bodoni Moda', serif;
}

.input-field{
    background: #eaeaea;
    margin: 15px 0;
    border-radius: 5px;
    display: flex;
    align-items: center;
    max-height: 65px;
    transition: max-height 1s;
    overflow: hidden;
    text-shadow: 2px 2px 5px black; 
    font-size: 1.2rem;
}

input{
    width: 100%;
    background: transparent;
    border: 0;
    outline: 0;
    padding: 18px 15px;
    color: black;
}

.input-field i {
    margin-left: 15px;
    /* color: #999; */
    color: orange;
}

.btn-field{
    width: 40%;
    display: flex;
    align-items: center;
}

.btn-field {
    margin-top: 30px;
    flex-basis: 48%;
    background: rgb(255, 158, 2);
    color: #fff;
    height: 50px;
    border-radius: 20px;
    border: 0;
    outline: 0;
    cursor: pointer;
    transition: backgroud 1s;
    width: 100%;
}

.disable{
    font-size: 2rem;
    padding: 10px;
    cursor: pointer;
    color: #fff;
}

.disable:hover{
    color: rgb(255, 17, 4);
}


        </style>
    <link rel="shortcut icon" href="../img/login.png" type="image/x-icon">
    <script src="https://kit.fontawesome.com/0eae2c197f.js" crossorigin="anonymous"></script>
</head>
<body>
 <form method="POST" >
        @csrf
            <table border='1'>
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Student Id</th>
                        <th>Name</th>
                        <th>Address</th>
                        <th>Email</th>
						<th colspan='2'></th>
                    </tr>
                </thead>
				<tbody>
                    
                        @foreach($students as $student)
                        <tr>
                        <td><input type="text" value="{{$student->id}}" disabled></td>
                        <td><input type="text" value="{{$student->studentid}}" disabled></td>
                        <td><input type="text" value="{{$student->name}}" disabled></td>
                        <td><input type="textarea" value="{{$student->address}}" disabled></td>
                        <td><input type="text" value="{{$student->email}}" disabled></td>
                        <td colspan=2>
                            <div class="btn-field">
                                <input type="submit" value="Edit"  class="disable"  formaction="{{route('update',['id'=> $student->id ])}}">
                                <input type="submit" value="Delete" class="disable" formaction="{{route('delete',['id'=> $student->id ])}}"></td>
                            </div>
                        </tr>
                        @endforeach
                  
				</tbody>
            </table>                                                          
        </form>
     
    <script src="https://kit.fontawesome.com/0eae2c197f.js" crossorigin="anonymous"></script>
</body>
</html>