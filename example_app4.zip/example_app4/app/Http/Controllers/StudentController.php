<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\StudInsertData;

class StudentController extends Controller
{
    public function index()
    {   
       //
    }
    public function insert(Request $req)
    {    
        $member=new StudInsertData;
        $member->studentid=$req->input('stdid');
        $member->name=$req->input('usname');
        $member->address=$req->input('add');
        $member->email=$req->input('email');
        $member->save();
        return redirect()->route('read');
    }
    public function retrive(Request $req)
    {
        $students = StudInsertData::get();
        return view('Insert.index',compact('students'));
    }

    public function delete(Request $req,$id)
    {
        $member = StudInsertData::find($id);
        $member->delete();
        return redirect()->route('read');
    }

    public function edit(Request $req,$id)
    {
        $student = StudInsertData::find($id);
        return view('Insert.update',compact('student'));
    }
    
    public function update(Request $req,$id)
    {
        $member = StudInsertData::find($id);
        $member->studentid=$req->input('stdid');
        $member->name=$req->input('usname');
        $member->address=$req->input('add');
        $member->email=$req->input('email');
        $member->save();
        return redirect()->route('read');
    }

}
