<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('Insert/insert');
});
Route::post('/',[App\Http\Controllers\StudentController::class,'insert'])->name('insert.save');
Route::any('/read',[App\Http\Controllers\StudentController::class,'retrive'])->name('read');
Route::Post('/edit/{id}',[App\Http\Controllers\StudentController::class,'update'])->name('update.save');
Route::any('/update/{id}',[App\Http\Controllers\StudentController::class,'edit'])->name('update');
Route::any('/read/{id}',[App\Http\Controllers\StudentController::class,'delete'])->name('delete');


